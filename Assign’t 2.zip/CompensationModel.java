public abstract class CompensationModel {
    public abstract double earnings();
}

