public class Teacher extends Person implements Printable {
   private final String teacherID;
   private final String department;

   public Teacher(String name, int age, String address, String teacherID, String department) {
      super(name, age, address);
      this.teacherID = teacherID;
      this.department = department;
   }

   public String getTeacherID() {
      return teacherID;
   }

   public String getDepartment() {
      return department;
   }
@Override
   public void printDetails() {
      System.out.println("Teacher Details:");
      System.out.println("Name: " + this.name + ", Age: " + this.age + ", Address: " + this.address);
      System.out.println("Teacher ID: " + this.teacherID + ", Department: " + this.department);
   }
}
