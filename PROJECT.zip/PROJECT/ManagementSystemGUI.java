import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ManagementSystemGUI extends JFrame {
    private List<Printable> records = new ArrayList<>();
    private DefaultTableModel tableModel;

    private JTextField nameField, ageField, addressField, idField, courseOrDeptField;
    private JComboBox<String> typeComboBox;
    private JTable recordTable;

    public ManagementSystemGUI() {
        setTitle("Student and Teacher Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(7, 2)); // 7 rows, 2 columns
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Age:"));
        ageField = new JTextField();
        inputPanel.add(ageField);

        inputPanel.add(new JLabel("Address:"));
        addressField = new JTextField();
        inputPanel.add(addressField);

        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Course/Department:"));
        courseOrDeptField = new JTextField();
        inputPanel.add(courseOrDeptField);

        inputPanel.add(new JLabel("Type:"));
        typeComboBox = new JComboBox<>(new String[]{"Student", "Teacher"});
        inputPanel.add(typeComboBox);

        // Buttons
        JButton addButton = new JButton("Add Record");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRecord();
            }
        });

        JButton displayButton = new JButton("Display Records");
        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayRecords();
            }
        });

        // Add buttons to the last row
        inputPanel.add(addButton);
        inputPanel.add(displayButton);

        // Table
        tableModel = new DefaultTableModel(new String[]{"Type", "Name", "Age", "Address", "ID", "Course/Department"}, 0);
        recordTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(recordTable);

        // Add components to frame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void addRecord() {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String address = addressField.getText();
        String id = idField.getText();
        String courseOrDept = courseOrDeptField.getText();

        if (typeComboBox.getSelectedItem().equals("Student")) {
            records.add(new Student(name, age, address, id, courseOrDept));
        } else {
            records.add(new Teacher(name, age, address, id, courseOrDept));
        }

        // Clear fields
        nameField.setText("");
        ageField.setText("");
        addressField.setText("");
        idField.setText("");
        courseOrDeptField.setText("");
    }

    private void displayRecords() {
        tableModel.setRowCount(0); // Clear the table
        for (Printable record : records) {
            if (record instanceof Student) {
                Student student = (Student) record;
                tableModel.addRow(new Object[]{"Student", student.getName(), student.getAge(), student.getAddress(), student.getStudentID(), student.getCourse()});
            } else if (record instanceof Teacher) {
                Teacher teacher = (Teacher) record;
                tableModel.addRow(new Object[]{"Teacher", teacher.getName(), teacher.getAge(), teacher.getAddress(), teacher.getTeacherID(), teacher.getDepartment()});
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ManagementSystemGUI().setVisible(true);
            }
        });
    }
}