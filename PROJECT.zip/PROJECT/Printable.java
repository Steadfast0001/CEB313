public interface Printable {
   void printDetails();
}
