import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class StudentManagementSystem {
   public StudentManagementSystem() {
   }

   public static void main(String[] args) {
      ArrayList<Printable> records = new ArrayList();
      Scanner scanner = new Scanner(System.in);

      while(true) {
         while(true) {
            while(true) {
               System.out.println("1. Add Student");
               System.out.println("2. Add Teacher");
               System.out.println("3. Display Records");
               System.out.println("4. Exit");
               System.out.print("Choose an option: ");
               int choice = scanner.nextInt();
               scanner.nextLine();
               switch (choice) {
                  case 1:
                     System.out.print("Enter Student Name: ");
                     String studentName = scanner.nextLine();
                     System.out.print("Enter Age: ");
                     int studentAge = scanner.nextInt();
                     scanner.nextLine();
                     System.out.print("Enter Address: ");
                     String studentAddress = scanner.nextLine();
                     System.out.print("Enter Student ID: ");
                     String studentID = scanner.nextLine();
                     System.out.print("Enter Course: ");
                     String course = scanner.nextLine();
                     records.add(new Student(studentName, studentAge, studentAddress, studentID, course));
                     System.out.println("Student added successfully");
                     break;
                  case 2:
                     System.out.print("Enter Teacher Name: ");
                     String teacherName = scanner.nextLine();
                     System.out.print("Enter Age: ");
                     int teacherAge = scanner.nextInt();
                     scanner.nextLine();
                     System.out.print("Enter Address: ");
                     String teacherAddress = scanner.nextLine();
                     System.out.print("Enter Teacher ID: ");
                     String teacherID = scanner.nextLine();
                     System.out.print("Enter Department: ");
                     String department = scanner.nextLine();
                     records.add(new Teacher(teacherName, teacherAge, teacherAddress, teacherID, department));
                     System.out.println("Teacher added successfully");
                     break;
                  case 3:
                     if (records.isEmpty()) {
                        System.out.println("There are no students in the system");
                        break;
                     }

                     System.out.println("\nDisplaying records:");
                     Iterator var14 = records.iterator();

                     while(var14.hasNext()) {
                        Printable record = (Printable)var14.next();
                        record.printDetails();
                     }
                     break;
                  case 4:
                     System.out.println("Exiting...");
                     scanner.close();
                     System.exit(0);
                  default:
                     System.out.println("Invalid choice. Try again.");
               }
            }
         }
      }
   }
}
