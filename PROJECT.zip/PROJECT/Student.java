public class Student extends Person implements Printable {
   private final String studentID;
   private final String course;

   public Student(String name, int age, String address, String studentID, String course) {
      super(name, age, address);
      this.studentID = studentID;
      this.course = course;
   }
   public String getStudentID() {
      return studentID;
   }

   public String getCourse() {
      return course;
   }
@Override
   public void printDetails() {
      System.out.println("Student Details:");
      System.out.println("Name: " + this.name + ", Age: " + this.age + ", Address: " + this.address);
      System.out.println("Student ID: " + this.studentID + ", Course: " + this.course);
   }

}
